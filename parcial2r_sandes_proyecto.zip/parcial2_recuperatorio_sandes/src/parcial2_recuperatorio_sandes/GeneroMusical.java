package parcial2_recuperatorio_sandes;

/**
 *
 * @author Julian Naim Sandes
 */
public enum GeneroMusical {
    ROCK,
    POP,
    JAZZ,
    CLASICA,
    ELECTRONICA
}
