package parcial2_recuperatorio_sandes;

import java.time.LocalDate;
import java.util.*;
import java.util.function.*;

/**
 *
 * @author Julian Naim Sandes
 * @param <T>
 */
public interface Inventariable<T extends Evento> {
    void agregar(T item);
    T obtenerElemento(int i);
    void eliminar(int i);
    
    List<T> filtrar(Predicate<T> pred);
    List<T> buscarPorRango(LocalDate f1, LocalDate f2);
    
    void ordenar(Comparator<T> comp);
    
    void guardarEnBinario(String p);
    void cargarDesdeBinario(String p);
    void guardarEnCSV(String p);
    void cargarDesdeCSV(String p, Function<String, T> funcion);
}
