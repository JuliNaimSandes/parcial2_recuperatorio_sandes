package parcial2_recuperatorio_sandes;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author Julian Naim Sandes
 */
public class EventoMusical extends Evento implements Comparable<EventoMusical>, Serializable, MetodosCSV {
    
    //Atributos
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    @Override
    public int compareTo(EventoMusical o) {
        return (getFecha().compareTo(o.getFecha())); //El orden natural es con las fechas.
    }
    
    //////////////////////
    //Metodos CSV
    @Override
    public String toCSV() { //Atributos separados con comas.
        return getId() + "," + getNombre() + "," + getFecha().toString() + "," + artista + "," + genero.toString();
    }
    
    //@Override
    public static EventoMusical fromCSV(String csv) {
        String [] valores = csv.split(",");
        return new EventoMusical(
            Integer.parseInt(valores[0]), 
            valores[1], 
            LocalDate.parse(valores[2]),
            valores[3],
            GeneroMusical.valueOf(valores[4])
        );
    }
    
    @Override
    public String toString() {
        return "EventoMusical{" + "id=" + getId()
                + ", nombre=" + getNombre()
                + ", fecha=" + getFecha().toString()
                + ", artista=" + artista
                + ", genero=" + genero + '}';
    }
    
    //Getters
    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }
    
    
}
