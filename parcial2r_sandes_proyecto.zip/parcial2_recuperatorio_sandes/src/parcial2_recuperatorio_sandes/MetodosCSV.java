package parcial2_recuperatorio_sandes;

/**
 *
 * @author Julian Naim Sandes
 */
public interface MetodosCSV {
    String toCSV();
    //EventoMusical fromCSV(String csv);
}
