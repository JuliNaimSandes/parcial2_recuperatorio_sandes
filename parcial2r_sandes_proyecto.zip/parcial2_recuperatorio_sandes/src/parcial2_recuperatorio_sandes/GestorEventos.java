package parcial2_recuperatorio_sandes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author Julian Naim Sandes
 * @param <T>
 */
public class GestorEventos<T extends Evento> implements Inventariable<T>  {
    
    List<T> eventos = new ArrayList<>();
    
    public GestorEventos() {
        eventos = new ArrayList<>();
    }
    
    //----------------------------------------//
    //           Metodos de Propios           //
    //----------------------------------------//
    public void ordenarNatural() {
        //Reutilizacion del metodo "ordenar". Orden natural de fechas.
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }
    
    public void limpiar(){
        eventos.clear();
    }
    
    public void mostrarTodos(){
        for(T item : eventos){
            System.out.println(item);
        }
    }
    
    
    //----------------------------------------//
    //        Metodos de Inventariable        //
    //----------------------------------------//
    @Override
    public void agregar(T item) {
        eventos.add(item);
    }

    @Override
    public T obtenerElemento(int i) {
        validarIndice(i); //Validacion de indice almacenado en este metodo.
        return eventos.get(i);
    }

    @Override
    public void eliminar(int i) {
        validarIndice(i);
        eventos.remove(i);
    }

    @Override
    public List<T> filtrar(Predicate<T> pred) {
        List<T> eventosRet = new ArrayList<>();
        
        for(T item : eventos){
            //Test con el predicado para saber cuales items cumplen.
            if(pred.test(item))
                eventosRet.add(item);
        }
        
        return eventosRet;
    }

    @Override
    public List<T> buscarPorRango(LocalDate f1, LocalDate f2) {
        List<T> eventosRet = new ArrayList<>();
        
        for(T item : eventos){
            //Solo entraran los eventos que esten despues de F1 y antes de F2.
            //Es decir, que esten en el rango adecuado.
            if(item.getFecha().isAfter(f1) && item.getFecha().isBefore(f2))
                eventosRet.add(item);
        }
        
        return eventosRet;
    }

    @Override
    public void ordenar(Comparator<T> comp) {
        eventos.sort(comp);
    }

    
    //----------------------------------------//
    //      Metodos de Guardado/Lectura       //
    //----------------------------------------//
    @Override
    public void guardarEnBinario(String p) {
        try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(p))){
            out.writeObject(eventos);
        } 
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String p) {
        limpiar(); //Se reemplaza la list por la que estaba almacenada en el binario.
        
        try(ObjectInputStream inp = new ObjectInputStream(new FileInputStream(p))){
            eventos = (List<T>) inp.readObject();
        } 
        catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }

    //CSV
    @Override
    public void guardarEnCSV(String p) {
        //Escritura a archivo de texto.
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(p))){
            bw.write("id,nombre,fecha,artista,genero\n");
            for (T item : eventos){
                bw.write(item.toCSV()+"\n");
            }
        } 
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String p, Function<String, T> funcion) {
        limpiar(); //Se reemplaza la list por la que estaba almacenada en el CSV.
        
        //Lectura de archivo de texto.
        try(BufferedReader br = new BufferedReader(new FileReader(p))){
            br.readLine(); //Bajo del encabezado.
            String l;
            while((l = br.readLine()) != null){
                eventos.add(funcion.apply(l));
            }
        } 
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    //Metodos privados.
    private void validarIndice(int i){
        if(!(i >= 0 && i < eventos.size())){
            throw new NullPointerException("ID dado invalido.");
        }
    }
}
